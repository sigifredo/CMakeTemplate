
#ifndef TYPES_HPP
#define TYPES_HPP

#ifndef _WIN32
#  warning "Terminar de documentar la enumeración"
#endif
/**
 * @enum Licence
 * \brief Tipo de licencia
 *
 */
enum Licence {
cluf,
lgpl3,
gpl3
};

#endif
